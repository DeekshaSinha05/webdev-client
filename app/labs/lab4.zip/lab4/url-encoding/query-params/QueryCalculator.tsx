
"use client";

import { useSearchParams } from "next/navigation";

export default function QueryCalculator() {
  const searchParams = useSearchParams();

  const aRaw = searchParams.get("a") || "0";
  const bRaw = searchParams.get("b") || "0";
  const personalC = searchParams.get("personalC");
  const sampleC = searchParams.get("c");
  const cRaw = personalC ?? sampleC;

  const a = parseFloat(aRaw);
  const b = parseFloat(bRaw);
  const c = cRaw === null ? 0 : parseFloat(cRaw);
  const sum = a + b + c;

  return (
    <div id="wd-query-calculator">
      <h1>Calculator – Query Parameters</h1>
      <p>Raw query values (already decoded by Next.js):</p>
      <p>
        a = <code>{aRaw}</code>
      </p>
      <p>
        b = <code>{bRaw}</code>
      </p>
      {cRaw !== null && (
        <p>
          c = <code>{cRaw}</code>
        </p>
      )}
      {personalC !== null && sampleC !== null && (
        <p>
          Sample c = <code>{sampleC}</code>
        </p>
      )}
      <h2 className="text-green-700">Sum = {sum}</h2>
    </div>
  );
}
