
import type { ReactNode } from "react";

export default function Module({
  title,
  children,
}: {
  title: string;
  children?: ReactNode;
}) {
  return (
    <li className="wd-module mb-6 list-none border border-gray-300">
      <div className="wd-title bg-gray-200 p-4 font-bold">
        {title}
      </div>
      <ul className="wd-lessons m-0 list-none p-0">
        {children}
      </ul>
    </li>
  );
}
